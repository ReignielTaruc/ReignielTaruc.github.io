﻿using System.Drawing;

public class Program
{
    const int N = 9;

    static bool IsSafe(int[,] board, int row, int col, int num)
    {
        for (int i = 0; i < N; i++)
            if (board[row, i] == num || board[i, col] == num)
                return false;

        int boxRowStart = row - row % 3;
        int boxColStart = col - col % 3;

        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                if (board[i + boxRowStart, j + boxColStart] == num)
                    return false;

        return true;
    }

    static void PrintBoard(int[,] grid)
    {
        Console.Clear();
        Console.WriteLine("\t\t\t<================================================================================>");
        Console.WriteLine("\t\t\t|                        WELCOME TO SUDOKU Game!                                 |");
        Console.WriteLine("\t\t\t|       Fill in the missing numbers(represented by 0) to solve the puzzle.       |");
        Console.WriteLine("\t\t\t<================================================================================>");
        for (int row = 0; row < N; row++)
        {
            for (int col = 0; col < N; col++)
            {
                if (col == 3 || col == 6)
                    Console.Write(" | ");
                Console.Write(grid[row, col] + " ");
            }
            if (row == 2 || row == 5)
            {
                Console.WriteLine();
                for (int i = 0; i < N; i++)
                    Console.Write("---");
            }
            Console.WriteLine();
        }
    }

    static bool SolveSudoku(int[,] board, int row, int col)
    {
        if (row == N - 1 && col == N)
            return true;

        if (col == N)
        {
            row++;
            col = 0;
        }

        if (board[row, col] != 0)
            return SolveSudoku(board, row, col + 1);

        for (int num = 1; num <= 9; num++)
        {
            if (IsSafe(board, row, col, num))
            {
                board[row, col] = num;

                if (SolveSudoku(board, row, col + 1))
                    return true;

                board[row, col] = 0;
            }
        }
        return false;
    }

    static bool IsSolvedCompletely(int[,] grid)
    {
        for (int row = 0; row < N; row++)
        {
            for (int col = 0; col < N; col++)
            {
                if (grid[row, col] == 0) 
                { 
                    return false;
                    }
            }
        }
        return true;
    }

    static void PlayGame(int[,] board)
    {
        int row, col, num;
        while (true)
        {
            PrintBoard(board);
            Console.WriteLine("\n\nUnable to solve? Enter -1 as row, col, and num to view the solved sudoku.");
            Console.Write("Enter row: ");
            row = int.Parse(Console.ReadLine());
            Console.Write("Enter column: ");
            col = int.Parse(Console.ReadLine());
            Console.Write("Enter number: ");
            num = int.Parse(Console.ReadLine());

            if (row == -1 || col == -1 || num == -1)
            {
                SolveSudoku(board, 0, 0);
                PrintBoard(board);
                Console.WriteLine("\nBetter luck next time!!!");
                return;
            }
            if (IsSolvedCompletely(board))
                break;
            row--;
            col--;
            if (!IsSafe(board, row, col, num))
            {
                Console.WriteLine("Invalid move. Try again.");
                continue;
            }
            board[row, col] = num;
        }

        bool solved = true;
        for (int i = 0; i < N; i++)
        {
            for (int j = 0; j < N; j++)
            {
                if (board[i, j] == 0)
                {
                    solved = false;
                    break;
                }
            }
        }

        if (solved)
        {
            Console.WriteLine("Congratulations! You have solved the puzzle.");
            PrintBoard(board);
        }
        else
        {
            Console.WriteLine("Puzzle not solved. Better luck next time.");
        }
    }

    static int[,] GenerateBoard(int size) //Board Generation based on the difficulty level
    {
        int[,] board = new int[size, size];
        // Generate a solved Sudoku board
        SolveSudoku(board, 0, 0);
        // Remove some numbers based on difficulty level
        Random rnd = new Random();
        int cellsToRemove = size switch
        {
            9 => rnd.Next(30, 40),
            12 => rnd.Next(50, 60),
            15 => rnd.Next(70, 80),
            _ => 0
        };

        while (cellsToRemove > 0)
        {
            int row = rnd.Next(size);
            int col = rnd.Next(size);
            if (board[row, col] != 0)
            {
                board[row, col] = 0;
                cellsToRemove--;
            }
        }

        return board;
    }

    static void PrintInitialBoard(int[,] grid)
    {
        Console.Clear();
        Console.WriteLine("\t\t\t<================================================================================>");
        Console.WriteLine("\t\t\t|                        WELCOME TO SUDOKU Game!                                 |");
        Console.WriteLine("\t\t\t|       Fill in the missing numbers(represented by 0) to solve the puzzle.       |");
        Console.WriteLine("\t\t\t<================================================================================>");
        for (int row = 0; row < grid.GetLength(0); row++)
        {
            for (int col = 0; col < grid.GetLength(1); col++)
            {
                if (col == 3 || col == 6 || col == 9 || col == 12)
                    Console.Write(" | ");
                Console.Write(grid[row, col] + " ");
            }
            if (row == 2 || row == 5 || row == 8 || row == 11)
            {
                Console.WriteLine();
                for (int i = 0; i < grid.GetLength(0); i++)
                    Console.Write("---");
            }
            Console.WriteLine();
        }
    }

    static void Main()
    {
        int size;
        int[,] board;
        Console.WriteLine("\t\t\t<================================================================================>");
        Console.WriteLine("\t\t\t|                        WELCOME TO SUDOKU Game!                                 |");
        Console.WriteLine("\t\t\t|       Fill in the missing numbers(represented by 0) to solve the puzzle.       |");
        Console.WriteLine("\t\t\t<================================================================================>");

        while (true)
        {
            Console.WriteLine("\n\n\t\t[1] Easy");
            Console.WriteLine("\t\t[2] Medium");
            Console.WriteLine("\t\t[3] Hard");
            Console.WriteLine("\t\t[4] Exit");
            Console.Write("\t\tEnter difficulty level (1-4): ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    size = 9;
                    board = GenerateBoard(size);
                    PrintInitialBoard(board);
                    PlayGame(board);
                    break;
                case 2:
                    size = 12;
                    board = GenerateBoard(size);
                    PrintInitialBoard(board);
                    PlayGame(board);
                    break;
                case 3:
                    size = 15;
                    board = GenerateBoard(size);
                    PrintInitialBoard(board);
                    PlayGame(board);
                    break;
                case 4:
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("\nInvalid choice");
                    break;
            }
        }
    }
}